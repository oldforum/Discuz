<?php
/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: cp.php 9379 2010-04-28 07:30:09Z zhengqingpeng $
 */

$_GET['mod'] = 'manage';
require_once 'userapp.php';
?>