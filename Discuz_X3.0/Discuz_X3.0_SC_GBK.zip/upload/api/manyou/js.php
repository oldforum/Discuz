<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: js.php 33854 2013-08-22 01:50:55Z hypowang $
 */

define('IN_API', true);
define('CURSCRIPT', 'api');

exit;